﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace ExcelAssessmentIntegration
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void readExcelSheet(object sender, EventArgs e)
        {
            //Manipulate an excel file/application variable
            Excel.Application excelApp;
            //workbook variable
            Excel.Workbook excelWorkbook;
            //worksheet variable
            Excel.Worksheet excelWorksheet;
            excelWorksheet = null;
            //range variable
            Excel.Range excelCell;
            Excel.Range range;
            //
            Excel.Range range1;
            Excel.Range range2;

            string str;
            int rCnt = 0;
            int cCnt = 0;

            //create a new application
            excelApp = new Excel.Application();

            //make excel visible to the user
            excelApp.Visible = true;

            // The following line if uncommented adds a new workbook
            //Excel.Workbook newWorkbook = excelApp.Workbooks.Add();

            //public Microsoft.Office.Interop.Excel.Workbook Open(string Filename, object UpdateLinks, 
            //object ReadOnly, object Format, object Password, object WriteResPassword, object IgnoreReadOnlyRecommended, 
            //object Origin, object Delimiter, object Editable, object Notify, object Converter, object AddToMru, object Local, 
            //object CorruptLoad);


            string workbookPath = ""; //PATH NEEDS TO BE ADDED
            try
            {
                excelWorkbook = excelApp.Workbooks.Open(workbookPath,
                   0, false, 5, "", "", false, Excel.XlPlatform.xlWindows, "",
                   true, false, 0, true, false, false);

                //sheets object to hold the worksheet
                Excel.Sheets excelSheets = excelWorkbook.Worksheets;

                //individual sheet for editing
                string currentSheet = "Sheet1";
                excelWorksheet = (Excel.Worksheet)excelSheets.get_Item(currentSheet);

                //Find all the cells that are being used
                range = excelWorksheet.UsedRange;

                //Number of rows
                Console.WriteLine("Number of Rows: " + range.Rows.Count);

                //Number of columns
                Console.WriteLine("Rumber of Columns: " + range.Columns.Count);

                for (rCnt = 1; rCnt <= range.Rows.Count; rCnt++)
                {
                    for (cCnt = 1; cCnt <= range.Columns.Count; cCnt++)
                    {
                        if (range.Cells[rCnt, cCnt].Value2 != null)
                        {
                            str = range.Cells[rCnt, cCnt].Value2.ToString();
                            Console.WriteLine("Value in cell " + rCnt + " " + cCnt + " is " + str);
                        }

                    }
                }

                /*excelCell = (Excel.Range)excelWorksheet.get_Range("G2", "G2");

                Console.WriteLine("Value in cell A1 is " + excelCell.get_Value());
                */

                // The following sets cell A1's value to "Hi There"
                //excelCell.Value2 = "Hi There";

                //close the workbook
                excelWorkbook.Close(true, null, null);
                excelApp.Quit();


            }
            catch (Exception e)
            {
                MessageBox.Show("ERROR: FILE NOT READ");
            }



        }
    }
}

